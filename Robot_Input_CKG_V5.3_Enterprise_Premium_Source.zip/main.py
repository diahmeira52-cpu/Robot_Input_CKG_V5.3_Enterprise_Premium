# Main application entry point
# TODO: connect CustomTkinter dashboard
